<?php
declare(strict_types=1);

/**
 * Локальные переопределения (не коммитьте секреты в git).
 * Файл автоматически подхватывается в includes/bootstrap.php.
 */
return [
    // При необходимости можно переопределить подключение к БД:
    // 'db' => [
    //     'host' => 'MySQL-8.4',
    //     'port' => 3306,
    //     'name' => 'planner',
    //     'user' => 'root',
    //     'pass' => '',
    // ],
  'app' => [
        /** Без этого CLI собирал неверный webhook URL. */
        'public_origin' => 'https://planiro75.ru',
        'public_base_path' => '/public',
    ],

'registration' => [
    'enabled' => true,
],
    'oauth' => [
        'yandex' => [
            'enabled' => true,
            'client_id' => 'e123475d08d848b8b3a8a89a797319a4',
            'client_secret' => '70cd9594f7f543ca9bac07fe54d8fbac',
            // Должен точно совпадать с Redirect URI в кабинете Яндекс OAuth.
            'redirect_uri' => 'https://planiro75.ru/public/auth/yandex_callback.php',
            'scope' => 'login:email login:info',
        ],
    ],
    'mail' => [
        'enabled' => true,
        'from_email' => 'do@iro75.ru',
        'from_name' => 'Planner',
        'smtp_host' => 'smtp.yandex.ru',
        'smtp_port' => 465,
        'smtp_encryption' => 'ssl',
        'smtp_user' => 'do@iro75.ru',
        'smtp_pass' => 'orjizeqptfqshkwc',
        'smtp_timeout' => 12,
    ],
    'max' => [
    'token' => 'f9LHodD0cOIYyG2RYtnPZMnO6YRjzBQPjRKBikIFUXyhf1q6ft4nDhY9F26eFytU88ysUvHMtsY9ddFp-yH4',
    'chat_id' => '284351356',
     'webhook_url' => 'https://planiro75.ru/public/api/max_webhook.php',
],
];
